create definer = root@localhost view view2 as
select `jxgl`.`sc`.`cno` AS `cno`, count(`jxgl`.`sc`.`cno`) AS `人数`, max(`jxgl`.`sc`.`degree`) AS `最高分`
from `jxgl`.`sc`
group by `jxgl`.`sc`.`cno`;

