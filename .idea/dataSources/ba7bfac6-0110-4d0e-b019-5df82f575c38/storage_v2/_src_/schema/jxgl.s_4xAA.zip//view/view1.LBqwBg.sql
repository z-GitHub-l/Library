create definer = root@localhost view view1 as
select `jxgl`.`student`.`sno`        AS `sno`,
       `jxgl`.`student`.`sname`      AS `sname`,
       `jxgl`.`student`.`ssex`       AS `ssex`,
       `jxgl`.`student`.`sbirthday`  AS `sbirthday`,
       `jxgl`.`student`.`sdept`      AS `sdept`,
       `jxgl`.`student`.`speciality` AS `speciality`
from `jxgl`.`student`
where (`jxgl`.`student`.`sdept` = 'CS');

